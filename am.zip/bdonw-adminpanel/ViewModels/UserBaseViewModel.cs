﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace bdonw_adminpanel.ViewModels
{
    public class UserBaseViewModel : INotifyPropertyChanged, IDisposable
    {
        public UserBaseViewModel()
        {}

        #region INotifyPropertyChanged IDisposable
        public event PropertyChangedEventHandler PropertyChanged;

        public virtual void NotifyOfProperty(string property)
        {
            PropertyChangedEventHandler handler = this.PropertyChanged;
            handler?.Invoke(this, new PropertyChangedEventArgs(property));
        }

        public void Dispose()
        {
            this.OnDispose();
        }

        protected virtual void OnDispose()
        {
            Dispose();
        }
        #endregion
    }
}
