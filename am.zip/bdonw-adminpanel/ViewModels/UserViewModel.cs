﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using bdonw_adminpanel.Models;

namespace bdonw_adminpanel.ViewModels
{
    public class UserViewModel : UserBaseViewModel
    {
        ObservableCollection<PersonElement> personElements { get; set; }
        PersonElement _person;

        public PersonElement PersonsElements
        {
            get
            {
                if (_person == null)
                    _person = new PersonElement();
                return _person;
            }
            set
            {
                _person = value;
                NotifyOfProperty("PersonsElements");
            }
        }
        /// <summary>
        /// // ТТу делати
        /// </summary>
        string tt;
        public string ttee
        {
            get { return tt; }
            set { tt = value; }
        }
        
        /// <summary>
        /// /NТТУ делати
        /// </summary>
        public ObservableCollection<PersonElement> PersonsElement
        {
            get
            {
                
                if (personElements == null)
                    switch (tt)
                    {
                        case "armor":
                            personElements = armor();
                            break;
                        case "ring":
                            personElements = ring();
                            break;
                    }
                return personElements;
            }
        }

        public string SelectId(int _id)
        {
            string Id = personElements[_id].ID;
            return Id;
        }

        //static string path = Path.Combine(Environment.CurrentDirectory, "Image", "Arsha.png");
        static Uri uri = new Uri(@"/Resources/armor/Arsha.png", UriKind.Relative);

        public static ObservableCollection<PersonElement> armor()
        {
            ObservableCollection<PersonElement> elements = new ObservableCollection<PersonElement>
            {
                new PersonElement{ cvet="#5ff369", ID = "10810", title = "Agerian Armor", defense = "7", attack = "-", evasion = "4 (+12)", damageReduction = "3 (+3)", accuracy="-", UrlImage = "/Resources/armor/Agerian Armor.png",effect1 = "Max HP+50",effect2 = "- 2-Set Effect: Max HP+100",effect3 = "- 3-Set Effect: Attack Speed +2 Level Casting Speed +2 Level"},
                new PersonElement{ cvet="#5ff369", ID = "10830", title = "Agerian Armor", defense = "7", attack = "-", evasion = "4 (+12)", damageReduction = "3 (+3)", accuracy="-", UrlImage = "/Resources/armor/Armor of Hercules' Might.png",effect1 = "Max HP+50",effect2 = "- 2-Set Effect: Max HP+100",effect3 = "- 3-Set Effect: Attack Speed +2 Level Casting Speed +2 Level"},
                new PersonElement{ cvet="yellow", ID = "10820", title = "Agerian Armor", defense = "7", attack = "-", evasion = "4 (+12)", damageReduction = "3 (+3)", accuracy="-", UrlImage = "/Resources/armor/Dim Tree Spirit's Armor.png",effect1 = "Max HP+50",effect2 = "- 2-Set Effect: Max HP+100",effect3 = "- 3-Set Effect: Attack Speed +2 Level Casting Speed +2 Level"},
            };

            return elements;
        }
        public static ObservableCollection<PersonElement> ring()
        {
            ObservableCollection<PersonElement> elements = new ObservableCollection<PersonElement>
            {
                 new PersonElement{ cvet="#5ff369", ID = "10810", title = "Agerian Armor", defense = "7", attack = "-", evasion = "4 (+12)", damageReduction = "3", accuracy="-", UrlImage = "/Resources/ring/[Event] Faint Old Moon Ring.png",effect1 = "Item Effect: All Accuracy ",effect2 = "- 2-Set Effect:",effect3 = "- 3-Set Effect:"},
                 new PersonElement{ cvet="#5ff369", ID = "10810", title = "Agerian Armor", defense = "7", attack = "-", evasion = "4 (+12)", damageReduction = "3", accuracy="-", UrlImage = "/Resources/ring/Alchemist's Ring.png",effect1 = "Item Effect: All Accuracy ",effect2 = "- 2-Set Effect:",effect3 = "- 3-Set Effect:"},
            };

            return elements;
        }
    }
}
