﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bdonw_adminpanel
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<State> States { get; } = new ObservableCollection<State>();
        public State SelectedState { get; set; }
        string code1;
        string name1;
        string select;
        string select2;
        string activcl;

        public MainWindow()
        {
            
            InitializeComponent();
            gradee.DataContext = new MainViewModel();
            DataContext = this;
            #region
            States.Add(new State() { Code = "add item [id] [count] [enchantLevel]", Name = ".bag add" });
            States.Add(new State() { Code = "add item to player [playerName] [itemId] [count] [enchantLevel]", Name = ".bag addtoplayer" });
            States.Add(new State() { Code = "ban chat [characterName] [minutes]", Name = ".ban chat" });
            States.Add(new State() { Code = "ban account [characterName] [minutes]", Name = ".ban account" });
            States.Add(new State() { Code = "ban player [characterName] [minutes]", Name = ".ban player" });
            States.Add(new State() { Code = "ban ip [characterName] [minutes]", Name = ".ban ip" });
            States.Add(new State() { Code = "ban hwid [characterName] [minutes]", Name = ".ban hwid" });
            States.Add(new State() { Code = "ban jail [characterName] [minutes]", Name = ".ban jail" });
            States.Add(new State() { Code = "ban unban [characterName] [...]", Name = ".ban unban" });
            States.Add(new State() { Code = "location", Name = ".location" });
            States.Add(new State() { Code = "announce [text]", Name = ".pc announce" });
            States.Add(new State() { Code = "kick [playerName]", Name = ".pc kick" });
            States.Add(new State() { Code = "gift online [itemId] [count] [enchantLevel]", Name = ".pc giftonline" });
            States.Add(new State() { Code = "set level [level]", Name = ".pc setlevel" });
            States.Add(new State() { Code = "add cash [cashCount]", Name = ".pc addcash" });
            States.Add(new State() { Code = "add tendency [tendencyCount]", Name = ".pc addtendency" });
            States.Add(new State() { Code = "add wp [wpCount]", Name = ".pc addwp" });
            States.Add(new State() { Code = "add exp [expCount]", Name = ".pc addexp" });
            States.Add(new State() { Code = "add skill exp [expCount]", Name = ".pc addskillexp" });
            States.Add(new State() { Code = "add skill points [pointsCount]", Name = ".pc addskillpoints" });
            States.Add(new State() { Code = "add life exp [lifeType] [expCount]", Name = ".pc addlifeexp" });
            States.Add(new State() { Code = "add fitness exp [fitnessType] [expCount]", Name = ".pc addfitnessexp" });
            States.Add(new State() { Code = "add explore exp  [nodeKey] [expCount]", Name = ".pc addexploreexp" });
            States.Add(new State() { Code = "add knowledge [cardId] [cardLevel]", Name = ".pc addknowledge" });
            States.Add(new State() { Code = "add title [titleId]", Name = ".pc addtitle" });
            States.Add(new State() { Code = "clear skill list", Name = ".pc clearskilllist" });
            States.Add(new State() { Code = "clear cooltime", Name = ".pc clearcooltime" });
            States.Add(new State() { Code = "openmap", Name = ".pc openmap" });
            States.Add(new State() { Code = "info", Name = ".pc info" });
            States.Add(new State() { Code = "gmspeed [level]", Name = ".pc gmspeed" });
            States.Add(new State() { Code = "heal", Name = ".pc heal" });
            States.Add(new State() { Code = "debug dmg", Name = ".pc debugdmg" });
            States.Add(new State() { Code = "kms", Name = ".pc kms" });
            States.Add(new State() { Code = "clear buffs", Name = ".pc clearbuffs" });
            States.Add(new State() { Code = "tp monster [npcId] [dialogIndex]", Name = ".tp monster" });
            States.Add(new State() { Code = "tp player [playerName]", Name = ".tp player" });
            States.Add(new State() { Code = "tp recall [playerName]", Name = ".tp recall" });
            States.Add(new State() { Code = "tp coord [x] [y] [z]", Name = ".tp coord" });
            States.Add(new State() { Code = "tp town [townId]", Name = ".tp town" });
            States.Add(new State() { Code = "help", Name = ".help" });
            States.Add(new State() { Code = "invis", Name = ".invis" });
            States.Add(new State() { Code = "quest start [groupId] [questId]", Name = ".quest start" });
            States.Add(new State() { Code = "quest complete [groupId] [questId]", Name = ".quest complete" });
            States.Add(new State() { Code = "quest update [groupId] [questId] [stepIndex] [stepCount]", Name = ".quest update" });
            States.Add(new State() { Code = "reload name [reloadableName]", Name = ".reload name" });
            States.Add(new State() { Code = "reload group [reloadableGroup]", Name = ".reload group" });
            States.Add(new State() { Code = "server shutdown [seconds]", Name = ".server shutdown" });
            States.Add(new State() { Code = "server restart [seconds]", Name = ".server restart" });
            States.Add(new State() { Code = "server abort", Name = ".server abort" });
            States.Add(new State() { Code = "server stat threadpool", Name = ".server stat threadpool" });
            States.Add(new State() { Code = "server memorydump", Name = ".server memorydump" });
            States.Add(new State() { Code = "spawn monster [creatureId] [optional: dialogId]", Name = ".spawn monster" });
            States.Add(new State() { Code = "restart AISector", Name = ".spawn restartAISector" });
            States.Add(new State() { Code = "kill near", Name = ".spawn killnear" });
            States.Add(new State() { Code = "kill id [creatureId]", Name = ".spawn killid" });
            #endregion
        }

        private void Main_Loaded(object sender, RoutedEventArgs e)
        {

            textcomand.Visibility = Visibility.Collapsed;
            Comand.Visibility = Visibility.Collapsed;
            slide.Margin = new Thickness(5, 0, 5, 0);
            bann.Margin = new Thickness(216, 10, 0, 0);
            Application.Current.MainWindow.Height = 50;
            Application.Current.MainWindow.Width = 50;
            border1.Visibility = Visibility.Collapsed;
            bann.Visibility = Visibility.Collapsed;
            groupId.Visibility = Visibility.Collapsed;
            questId.Visibility = Visibility.Collapsed;
            groupId.Margin = new Thickness(10, 40, 0, 0);
            questId.Margin = new Thickness(70, 40, 0, 0);
        }
        private void Slide_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.MainWindow.Height = 100;
            Application.Current.MainWindow.Width = 288;
            Comand.Visibility = Visibility.Visible;
            slide.Visibility = Visibility.Collapsed;
        }

        private void Main_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Back)
            {
                System.Windows.Application.Current.Shutdown();
            }
        }

        private void Backk_Click(object sender, RoutedEventArgs e)
        {
            slide.Visibility = Visibility.Visible;
            Comand.Visibility = Visibility.Collapsed;
            border1.Visibility = Visibility.Collapsed;
            slide.Margin = new Thickness(5, 0, 5, 0);
            Application.Current.MainWindow.Height = 50;
            Application.Current.MainWindow.Width = 50;
        }

        private void rightp_Click(object sender, RoutedEventArgs e)
        {
            border1.Visibility = Visibility.Visible;
            Application.Current.MainWindow.Height = 420;
            Application.Current.MainWindow.Width = 649;
        }
 
        private void Comand_SelectionChanged(object sender, EventArgs e)
        {
            
            if (SelectedState != null)
            {
                code1 = SelectedState.Code;
                name1 = SelectedState.Name;

                switch (name1)
                {
                     case ".bag add":
                        textcomand.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".bag addtoplayer":
                        textcomand.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".ban chat":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".ban account":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".ban player":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".ban ip":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".ban hwid":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".ban jail":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".ban unban":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Visible;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".location":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc announce":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc kick":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc giftonline":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Visible;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc setlevel":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addcash":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addtendency":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addwp":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addexp":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addskillexp":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addskillpoints":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addlifeexp":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addfitnessexp":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addexploreexp":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addknowledge":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc addtitle":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc clearskilllist":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc clearcooltime":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc openmap":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc info":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc gmspeed":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc heal":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc kms":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc debugdmg":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".pc clearbuffs":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".tp monster":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        break;
                    case ".tp player":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".tp recall":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".tp coord":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".tp town":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".help":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".invis":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".server shutdown":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".server restart":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".server abort":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".server stat threadpool":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".server memorydump":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".spawn monster":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".spawn restartAISector":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".spawn killnear":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".spawn killid":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".reload name":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".reload group":
                        textcomand.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                    case ".quest start":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Visible;
                        questId.Visibility = Visibility.Visible;
                        break;
                    case ".quest complete":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Collapsed;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Visible;
                        questId.Visibility = Visibility.Visible;
                        break;
                    case ".quest update":
                        textcomand.Visibility = Visibility.Collapsed;
                        countt.Visibility = Visibility.Visible;
                        gradee.Visibility = Visibility.Collapsed;
                        ID.Visibility = Visibility.Visible;
                        bann.Visibility = Visibility.Collapsed;
                        groupId.Visibility = Visibility.Visible;
                        questId.Visibility = Visibility.Visible;
                        break;
                    default:
                        bann.Visibility = Visibility.Collapsed;
                        textcomand.Visibility = Visibility.Collapsed;
                        gradee.Visibility = Visibility.Visible;
                        countt.Visibility = Visibility.Visible;
                        ID.Visibility = Visibility.Visible;
                        groupId.Visibility = Visibility.Collapsed;
                        questId.Visibility = Visibility.Collapsed;
                        break;
                }
            }
        }
        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            switch (name1)
            {
                case ".bag add":
                    Clipboard.SetText(name1 + " " + ID.Text + " " + countt.Text + " " + gradee.SelectedValue);
                    break;
                case ".bag addtoplayer":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + ID.Text + " " + countt.Text + " " + gradee.SelectedValue);
                    break;
                case ".ban chat":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + countt.Text);
                    break;
                case ".ban account":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + countt.Text);
                    break;
                case ".ban player":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + countt.Text);
                    break;
                case ".ban ip":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + countt.Text);
                    break;
                case ".ban hwid":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + countt.Text);
                    break;
                case ".ban jail":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + countt.Text);
                    break;
                case ".ban unban":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + bann.Text);
                    break;
                case ".location":
                    Clipboard.SetText(name1);
                    break;
                case ".pc announce":
                    Clipboard.SetText(name1 + " " + textcomand.Text);
                    break;
                case ".pc kick":
                    Clipboard.SetText(name1 + " " + textcomand.Text);
                    break;
                case ".pc giftonline":
                    Clipboard.SetText(name1 + " " + ID.Text + " " + countt.Text + " " + gradee.SelectedValue);
                    break;
                case ".pc setlevel":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".pc addcash":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".pc addtendency":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".pc addwp":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".pc addexp":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".pc addskillexp":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".pc addskillpoints":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".pc addlifeexp":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + countt.Text);
                    break;
                case ".pc addfitnessexp":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + countt.Text);
                    break;
                case ".pc addexploreexp":
                    Clipboard.SetText(name1 + " " + textcomand.Text + " " + countt.Text);
                    break;
                case ".pc addknowledge":
                    Clipboard.SetText(name1 + " " + ID.Text + " " + countt.Text);
                    break;
                case ".pc addtitle":
                    Clipboard.SetText(name1 + " " + ID.Text);
                    break;
                case ".pc clearskilllist":
                    Clipboard.SetText(name1);
                    break;
                case ".pc clearcooltime":
                    Clipboard.SetText(name1);
                    break;
                case ".pc openmap":
                    Clipboard.SetText(name1);
                    break;
                case ".pc info":
                    Clipboard.SetText(name1);
                    break;
                case ".pc gmspeed":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".pc heal":
                    Clipboard.SetText(name1);
                    break;
                case ".pc debugdmg":
                    Clipboard.SetText(name1);
                    break;
                case ".pc kms":
                    Clipboard.SetText(name1);
                    break;
                case ".pc clearbuffs":
                    Clipboard.SetText(name1);
                    break;
                case ".tp monster":
                    Clipboard.SetText(name1 + " " + ID.Text + " " + countt.Text);
                    break;
                case ".tp player":
                    Clipboard.SetText(name1 + " " + textcomand.Text);
                    break;
                case ".tp recall":
                    Clipboard.SetText(name1 + " " + textcomand.Text);
                    break;
                case ".tp coord":
                    Clipboard.SetText(name1 + " " + textcomand.Text);
                    break;
                case ".tp town":
                    Clipboard.SetText(name1 + " " + ID.Text);
                    break;
                case ".help":
                    Clipboard.SetText(name1);
                    break;
                case ".invis":
                    Clipboard.SetText(name1);
                    break;
                case ".quest start":
                    Clipboard.SetText(name1 + " " + groupId.Text + " " + questId.Text);
                    break;
                case ".quest complete":
                    Clipboard.SetText(name1 + " " + groupId.Text + " " + questId.Text);
                    break;
                case ".quest update":
                    Clipboard.SetText(name1 + " " + groupId.Text + " " + questId.Text + " " + ID.Text + " " + countt.Text);
                    break;
                case ".reload name":
                    Clipboard.SetText(name1 + " " + textcomand.Text);
                    break;
                case ".reload group":
                    Clipboard.SetText(name1 + " " + textcomand.Text);
                    break;
                case ".server shutdown":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".server restart":
                    Clipboard.SetText(name1 + " " + countt.Text);
                    break;
                case ".server abort":
                    Clipboard.SetText(name1);
                    break;
                case ".server stat threadpool":
                    Clipboard.SetText(name1);
                    break;
                case ".server memorydump":
                    Clipboard.SetText(name1);
                    break;
                case ".spawn monster":
                    Clipboard.SetText(name1 + " " + ID.Text + " " + countt.Text);
                    break;
                case ".spawn restartAISector":
                    Clipboard.SetText(name1);
                    break;
                case ".spawn killnear":
                    Clipboard.SetText(name1);
                    break;
                case ".spawn killid":
                    Clipboard.SetText(name1 + " " + ID.Text);
                    break;
            }
        }
        private void ID_Enter(object sender, RoutedEventArgs e)
        {
            ID.Text = Window1.quantity;
            if (ID.Text == "ID")
                ID.Clear();
            if (countt.Text == "COUNT")
                countt.Clear();
            if (ID.Text == "groupId")
                ID.Clear();
            if (ID.Text == "questId")
                ID.Clear();
        }

        private void Selectclass_Click(object sender, RoutedEventArgs e)
        {
            select = ((Button)sender).Name.ToString();
        }

        private void Armor_Click(object sender, RoutedEventArgs e)
        {
            select2 = ((Button)sender).Name.ToString();
            switch (select2)
            {
                case "armor":
                case "ring":
                case "gloves":
                case "belt":
                case "boots":
                case "earrings":
                case "helmet":
                case "necklace":
                    MyMethod2();
                    break;
            }
                 switch (select)
            {
                case "Sorceress":
                    switch (select2)
                    {
                        case "shield":
                        case "awakening":
                        case "dagger":
                        case "armor1":
                        case "gloves1":
                        case "shield1":
                        case "cape":
                        case "awakening1":
                        case "dagger1":
                        case "boots1":
                        case "helmet1":
                            MyMethod();
                            break;
                    }
                    break;
                case "Berserker":
                    switch (select2)
                    {
                        case "shield":
                        case "awakening":
                        case "dagger":
                        case "armor1":
                        case "gloves1":
                        case "shield1":
                        case "cape":
                        case "awakening1":
                        case "dagger1":
                        case "boots1":
                        case "helmet1":
                            MyMethod();
                            break;
                    }
                    break;
                case "Dark_Knight":
                    switch (select2)
                    {
                        case "shield":
                        case "awakening":
                        case "dagger":
                        case "armor1":
                        case "gloves1":
                        case "shield1":
                        case "cape":
                        case "awakening1":
                        case "dagger1":
                        case "boots1":
                        case "helmet1":
                            MyMethod();
                            break;
                    }
                    break;

            }
        }
        private void MyMethod()
        {
            activcl = (select +"_"+ select2);
            Window1 win2 = new Window1();
            win2.tte = this.activcl;
            win2.Show();
        }
        private void MyMethod2()
        {
            activcl = (select2);
            Window1 win2 = new Window1();
            win2.tte = this.activcl;
            win2.Show();
        }
    }

}
