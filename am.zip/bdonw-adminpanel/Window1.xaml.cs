﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using bdonw_adminpanel.MyControl;
using bdonw_adminpanel.ViewModels;

namespace bdonw_adminpanel
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public static string quantity;
        static UserViewModel userView;
        static ListBoxItemControl boxItemControl;
        string ttt;
        public Window1()
        {
            InitializeComponent();
        }
        public string tte
        {
            get { return ttt; }
            set { ttt = value; }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            userView = new UserViewModel();
            userView.ttee = ttt;
            list.DataContext = userView;
        }

        private void list_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            {
                int _id = list.SelectedIndex;
                if (_id != -1)
                {
                    string IDD = userView.SelectId(_id);
                    quantity = IDD;
                }
                else
                    return;
            }
        }
        
    }
}