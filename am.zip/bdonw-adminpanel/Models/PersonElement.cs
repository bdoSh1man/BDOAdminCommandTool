﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace bdonw_adminpanel.Models
{
    public class PersonElement
    {
        public string title { get; set; }
        public string defense { get; set; }
        public string attack { get; set; }
        public string evasion { get; set; }
        public string accuracy { get; set; }
        public string effect1 { get; set; }
        public string effect2 { get; set; }
        public string effect3 { get; set; }
        public string cvet { get; set; }
        public string damageReduction { get; set; }
        public string ID { get; set; }
        public string UrlImage { get; set; }
    }
}
